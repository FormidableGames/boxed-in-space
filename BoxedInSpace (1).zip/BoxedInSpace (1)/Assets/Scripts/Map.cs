﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map
{
    private List<List<GameObject>> matrix;
    private GameObject player, wall, tile, laser, crackedWall, ice, bridge, battery, exit, keyButton, iceButton, laserButton, enemy0, enemy1, enemy2;
    private Controller controller;
	private Player playerInScene;
	private List<GenericEnemy> enemiesInScene = new List<GenericEnemy>();
	private EnemyController enemyController;
	private float tileSize = 1.6f;

    public Map(Controller controller_, string[] level_, int width_, GameObject player_, GameObject[] tileSet_)
    {
        controller = controller_;
		player = player_;
		enemyController = new EnemyController(controller);
		
        foreach (GameObject p in tileSet_)
        {
            if (p.GetComponent<Wall>() != null) wall = p;
            else if (p.GetComponent<Tile>() != null) tile = p;
            else if (p.GetComponent<Laser>() != null) laser = p;
			else if (p.GetComponent<CrackedWall>() != null) crackedWall = p;
            else if (p.GetComponent<Ice>() != null) ice = p;
            else if (p.GetComponent<Bridge>() != null) bridge = p;
            else if (p.GetComponent<Battery>() != null) battery = p;
            else if (p.GetComponent<Exit>() != null) exit = p;
            else if (p.GetComponent<KeyButton>() != null) keyButton = p;
            else if (p.GetComponent<IceButton>() != null) iceButton = p;
            else if (p.GetComponent<LaserButton>() != null) laserButton = p;

            else if (p.GetComponent<WithGasEnemy>() != null) enemy0 = p;
			else if (p.GetComponent<LinearEnemy>() != null) enemy1 = p;
			else if (p.GetComponent<SkaterEnemy>() != null) enemy2 = p;
			
        }
        parseLevel(level_, width_);              
    }

    private void parseLevel(string[] level, int width)
    {
        matrix = new List<List<GameObject>>();

        GenericProp obj = null;
        for (int i = 0; i < level.Length/width; i++)
        {
            matrix.Add(new List<GameObject>());
            for (int j = 0; j < width; j++)
            {
                /*
                JUGADOR - J
                PARED - W
                SUELO - T
                SALIDA - E
                BLOQUES RESQUEBRAJADOS - C
                HIELO - I0 Apagado, I1 Encendido
                LASER - L + 0 Apagado, 1 Encendido + N Norte, S Sur, E Este, W Oeste +0,1,2(Ejemplo: L1S)
                PUENTE - P0 Apagado, P1 Encendido
                BATERÍA - B (Siempre apagada)
                BOTONES - BK Botón llave, BI Botón hielo, BL Botón laser
                VACIO - V (Cualquier letra sin uso sirve realmente)
				
				OBJETO - O + 0 Bomba, 1 Deshidratador, 2 Bola de luces, 3 autodestructor
				
				ENEMIGO - A + 
								0 Conga + H Horario, A Antihorario + 0,1,2
																	 7   3
																	 6,5,4
								1 Normal + H Horizontal, V Vertical 
								
								2 Patines + NW, NE, SE, SW
								(Ejemplo: A0H2 es un alien conga que va en sentido horario y empieza en la posición 2)
								(Ejemplo: A2SW es un alien con patines que empieza en la dirección suroeste)
                */
				
				string key = level[i*width+j];
				
				switch (key[0])
                {
                    case 'J':
                        GameObject p = GameObject.Instantiate(player);
						p.GetComponent<Player>().setController(controller);
                        p.GetComponent<Player>().setPos(new Vector2(i, j));
						playerInScene = p.GetComponent<Player>();
                        addObj(tile, i, j);
                        break;
                    case 'W':
                        addObj(wall, i, j);
                        break;
                    case 'T':
                        addObj(tile, i, j);
                        break;
                    case 'E':
                        addObj(exit, i, j);
                        break;
                    case 'C':
                        GenericProp o = addObj(crackedWall, i, j);
                        o.GetComponent<CrackedWall>().setTile(createProp(tile, i, j));
                        break;
                    case 'I':
                        obj = addObj(ice, i, j);
						if(key[1] == '0') obj.GetComponent<Ice>().unfreeze();
						else obj.GetComponent<Ice>().freeze();
                        break;
                    case 'L':
						createProp(tile, i, j);
                        laserParser(key, i, j);
                        break;
                    case 'P':
                        obj = addObj(bridge, i, j);
						if(key[1] == '0') obj.GetComponent<Bridge>().setOn(false);
						else obj.GetComponent<Bridge>().setOn(true);
                        break;
                    case 'B':
                        if (key[1] == 'K') addObj(keyButton, i, j);
                        else if (key[1] == 'I') addObj(iceButton, i, j);
                        else if (key[1] == 'L') addObj(laserButton, i, j);
                        else addObj(battery, i, j);
                        break;
                    case 'O':
                        obj = addObj(tile, i, j);
						obj.GetComponent<Tile>().createObj((int)System.Char.GetNumericValue(key[1])); // key[1] contains the type of object
                        break;
					case 'A':
						alienParser(key, i, j);
						obj = addObj(tile, i, j);
						break;
                    default:
						matrix[i].Add(new GameObject("Empty"));
                        break;
                }
            }
        }
    }
	
	
    public List<GameObject> getPropsOfType<T>() {
        List<GameObject> props = new List<GameObject>();
        for (int i = 0; i < matrix.Count; i++)
        {
            for (int j = 0; j < matrix[i].Count; j++)
            {
                if (matrix[i][j].GetComponent<T>() != null) props.Add(matrix[i][j]);
            }
        }
        return props;
    }
	
	// Comprobar la posición del jugador
	public bool isPlayerInPosition(Vector2 pos)
	{
		return playerInScene.getPos().Equals(pos);
	}
	
	// Obtener el GameObject de la matriz dadas una posicion inicial y una dirección
	public GameObject getTileInfo(Vector2 pos, Vector2 dir) 
	{
		GameObject prop;
		
		Vector2 newPos = pos + dir;
		
		if(newPos.x>=0 && newPos.y>=0 && ((int)newPos.x < matrix.Count) && ((int)newPos.y < matrix[(int)newPos.x].Count))
			prop = matrix[(int)newPos.x][(int)newPos.y];
		else
		{
			Debug.Log("ACCESO DENEGADO A "+newPos);
			prop = null;
		}
			
		
		return prop;
	}
	
	// Marcar todas las casillas como no letales (al final del turno)
	public void setAllToNonLethal()
	{
		for (int i = 0; i < matrix.Count; i++)
        {
            for (int j = 0; j < matrix[i].Count; j++)
            {
                matrix[i][j].GetComponent<GenericProp>().setLethal(false);
            }
        }
	}
	
	// Creación y adición de props
	
	private GenericProp addObj(GameObject obj, int i, int j)
	{
		return addPropToMatrix(createProp(obj, i, j), i);
	}
	
	public GameObject createProp(GameObject prop_, int i, int j)
	{ 
		GameObject prop = GameObject.Instantiate(prop_);
		prop.GetComponent<GenericProp>().setController(controller);
		prop.GetComponent<GenericProp>().setPos(new Vector2(i, j));
		return prop;
	}
	
	public GenericProp addPropToMatrix(GameObject prop_, int i)
	{
		matrix[i].Add(prop_);
		return prop_.GetComponent<GenericProp>();
	}
	
	public void setPropInMatrix(GameObject prop_, int i, int j)
	{
		matrix[i][j] = prop_;
	}

    private void laserParser(string s, int i, int j)
    {
        Laser l = (Laser)addObj(laser, i, j);

        if(s[1] == '0')
            l.setOn(false);
        else
            l.setOn(true);

        switch (s[2])
        {
            case 'N':
                l.setDir(new Vector2(0, 1));
                break;
            case 'E':
                l.setDir(new Vector2(1, 0));
                break;
            case 'S':
                l.setDir(new Vector2(0, -1));
                break;
            case 'W':
                l.setDir(new Vector2(-1, 0));
                break;
        }

        switch (s[3])
        {
            case '0':
                l.setTurn(0);
                break;
            case '1':
                l.setTurn(1);
                break;
            case '2':
                l.setTurn(2);
                break;
        }

    }
	
	private void alienParser(string key, int i, int j)
	{
		/*
	ENEMIGO - A + 
				0 Conga + H Horario, A Antihorario + 0,1,2
													 7   3
													 6,5,4
				1 Normal + H Horizontal, V Vertical 
				
				2 Patines + NW, NE, SE, SW
				(Ejemplo: A0H2 es un alien conga que va en sentido horario y empieza en la posición 2)
				(Ejemplo: A2SW es un alien con patines que empieza en la dirección suroeste)
	*/
	
		GameObject e = null;
		
		switch(key[1])
		{
			case '0':
			e = GameObject.Instantiate(enemy0);
			e.GetComponent<GenericEnemy>().setController(controller);
			e.GetComponent<GenericEnemy>().setPos(new Vector2(i, j));
			
			e.GetComponent<WithGasEnemy>().setPath(key[2], (int)System.Char.GetNumericValue(key[3]));
			break;
			
			case '1':
			e = GameObject.Instantiate(enemy1);
			e.GetComponent<GenericEnemy>().setController(controller);
			e.GetComponent<GenericEnemy>().setPos(new Vector2(i, j));
			
			if(key[2] == 'H'){
				e.GetComponent<LinearEnemy>().setGlobalMovement(LinearEnemy.LinearEnemyMovements.HORIZONTAL);
			}else{
				e.GetComponent<LinearEnemy>().setGlobalMovement(LinearEnemy.LinearEnemyMovements.VERTICAL);}
			
			break;
			
			case '2':
			e = GameObject.Instantiate(enemy2);
			e.GetComponent<GenericEnemy>().setController(controller);
			e.GetComponent<GenericEnemy>().setPos(new Vector2(i, j));
			
			string p = ""+key[2]+key[3];
			e.GetComponent<SkaterEnemy>().setPath(p);
			break;
			default:
			break;
		}
		
		if(e!=null) enemiesInScene.Add(e.GetComponent<GenericEnemy>());
		
	}

	
	/////////////////////
	// GETTERS & SETTERS
	
    public List<List<GameObject>> getMatrix() { return matrix; }
	public Player getPlayerInScene(){return playerInScene;}
	public List<GenericEnemy> getEnemiesInScene(){ return enemiesInScene;}
	public EnemyController getEnemyController(){ return enemyController;}
	public float getTileSize(){return tileSize;}
}