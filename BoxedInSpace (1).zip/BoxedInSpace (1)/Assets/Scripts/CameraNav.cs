﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraNav : MonoBehaviour
{
	Transform cam;
	Transform target;
	
	Vector3 localRotation;
	float camDistance = 10f;
	
	public float mouseSensitivity = 4f;
	public float scrollSensitivity = 2f;
	public float orbitDamp = 10f;
	public float scrollDamp = 6f;
	
	void Start()
	{
		cam = transform;
	}
	
	void LateUpdate()
	{
		if(Input.GetAxis("Mouse X") != 0  ||  Input.GetAxis("Mouse Y") != 0)
		{
			localRotation.x += Input.GetAxis("Mouse X") * mouseSensitivity;
			localRotation.y -= Input.GetAxis("Mouse Y") * mouseSensitivity;
			localRotation.y = Mathf.Clamp(localRotation.y, 0f, 90f);
		}
		
		if(Input.GetAxis("Mouse ScrollWheel") != 0f)
		{
			float scrollAmount = Input.GetAxis("Mouse ScrollWheel") * scrollSensitivity;
			scrollAmount *= (camDistance * 0.3f);
			camDistance += scrollAmount * -1f;
			camDistance = Mathf.Clamp(camDistance, 1.5f, 100f);
		}
		
		Quaternion rot = Quaternion.Euler(localRotation.y, localRotation.x, 0);
		transform.rotation = Quaternion.Lerp(transform.rotation, rot, Time.deltaTime * orbitDamp);
		if(cam.localPosition.z != camDistance*-1f)
		{
			cam.localPosition = new Vector3(0f, 0f, Mathf.Lerp(cam.localPosition.z, camDistance*-1f, Time.deltaTime*scrollDamp));
		}
	}
	
	
	public void setTarget(Transform target_){target = target_;}
	
	
	
	
	/*
	
	// CON YAW Y PITCH
	
	[SerializeField]float speedH = 2.0f;
	[SerializeField]float speedV = 2.0f;
	
	float yaw = 0.0f;
	float pitch = 0.0f;
	
	void Update()
	{
		yaw += speedH * Input.GetAxis("Mouse X");
		pitch -= speedV * Input.GetAxis("Mouse Y");
		
		transform.eulerAngles = new Vector3(pitch, yaw, 0f);
	}
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	
	//AVANZA EN TODAS LAS DIRECCIONES CON TECLADO
	
	float speed = 7.0f;
	
    void Update()
    {
        if(Input.GetKey(KeyCode.RightArrow))
		{
			transform.Translate(new Vector3(speed * Time.deltaTime,0,0));
		}
		if(Input.GetKey(KeyCode.LeftArrow))
		{
			transform.Translate(new Vector3(-speed * Time.deltaTime,0,0));
		}
		if(Input.GetKey(KeyCode.DownArrow))
		{
			transform.Translate(new Vector3(0,0,-speed * Time.deltaTime));
		}
		if(Input.GetKey(KeyCode.UpArrow))
		{
			transform.Translate(new Vector3(0,0,speed * Time.deltaTime));
		}
		if(Input.GetKey(KeyCode.O))
		{
			transform.Translate(new Vector3(0,speed * Time.deltaTime,0));
		}
		if(Input.GetKey(KeyCode.L))
		{
			transform.Translate(new Vector3(0,-speed * Time.deltaTime,0));
		}
    }
	
	*/
}
