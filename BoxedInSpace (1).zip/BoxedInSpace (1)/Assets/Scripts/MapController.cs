﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapController
{
    private List<GameObject[]> tileSets;
    private GameObject player;
    private Controller controller;
    private TextAsset json;

    public MapController(Controller controller_, GameObject player_, GameObject[] easy, GameObject[] medium, GameObject[] hard)
    {
        controller = controller_;
        player = player_;
        tileSets = new List<GameObject[]>() { easy, medium, hard };
        json = Resources.Load("levels") as TextAsset;
    }
    public Map create(int difficulty)
    {
        GameObject[] set = null;
        switch (difficulty)
        {
            case 0:
                set = tileSets[0];
                break;
            case 1:
                set = tileSets[1];
                break;
            case 2:
                set = tileSets[2];
                break;
        }
        Levels levels = JsonUtility.FromJson<Levels>(json.ToString());
        Level level = null;
        if (Data.difficulty == 0) level = levels.easy[0];
        else if (Data.difficulty == 1) level = levels.normal[0];

        return new Map(controller, level.level, level.width, player, set);
    }

}

[System.Serializable]
public class Levels
{
    public Level[] easy, normal, hard;
}
[System.Serializable]
public class Level
{
    public string[] level;
    public int difficulty, width;
}