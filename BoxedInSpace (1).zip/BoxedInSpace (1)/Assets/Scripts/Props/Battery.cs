﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Battery : GenericProp
{
    private bool activated;

    override protected void Start()
    {
        base.Start();
        setHeight(1);
        activated = false;
        walkable = false;
    }

    public void activate()
    {
        if (!activated)
        {
            activated = true;

			Debug.Log("BATERY ACTIVATED!!!");
            List<GameObject> props = controller.getMap().getPropsOfType<ElectricProp>();
            foreach (GameObject p in props)
            {
                p.GetComponent<ElectricProp>().setOn(true);
            }
        }
    }
}
