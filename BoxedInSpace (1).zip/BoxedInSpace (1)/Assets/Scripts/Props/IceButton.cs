﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IceButton : GenericButton
{
    override public void press()
    {
        List<GameObject> props = controller.getMap().getPropsOfType<Ice>();
        foreach (GameObject p in props)
        {
            p.GetComponent<Ice>().unfreeze();
        }
    }
}
