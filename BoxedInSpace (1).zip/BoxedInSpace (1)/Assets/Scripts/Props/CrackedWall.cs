﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrackedWall : GenericProp
{
	private GameObject tile;
	
    override protected void Start()
    {
        base.Start();
        setHeight(1);
        walkable = false;
    }
	
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q)) destroy();
    }
	
    public void destroy()
    {
        ParticleSystem part = GetComponentInChildren<ParticleSystem>();
        if (!part.isPlaying)
        {
            GameObject.Destroy(part.gameObject, part.duration + part.startLifetime);
            part.Play();
            //part.loop = true;
            part.transform.parent = null;
        }
        
		// Set tile in matrix
		controller.getMap().setPropInMatrix(tile, (int)pos.x, (int)pos.y);
		GameObject.Destroy(gameObject);
    }
	
	public void setTile(GameObject tile_){ tile = tile_;}
	
	
	
}
