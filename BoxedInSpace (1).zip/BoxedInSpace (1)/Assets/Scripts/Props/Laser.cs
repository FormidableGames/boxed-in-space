﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : ElectricProp
{
    public GameObject bullet;

    private Vector2 dir;
    private List<Bullet> bullets;
    protected int turn;

    override protected void Start()
    {
        base.Start();
        setHeight(1);
        walkable = false;
        transform.eulerAngles = new Vector3(0, 90 + Mathf.Max(0, dir.x) * 180 + dir.y * 90, 0);
        bullets = new List<Bullet>();
        broadcast();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q)) broadcast();
    }
    public void broadcast()
    {
        turn++;
        if (turn == 3) turn = 0;

        clearBullets();

        //Shoot
        if (turn == 0) {
            shoot();         
        }
    }

    public void rotate()
    {
        dir = new Vector2(dir.y, -dir.x);
        gameObject.transform.Rotate(Vector3.up * 90);
        if (turn == 0)
        {
            clearBullets();
            shoot();
        }
    }
    private void shoot()
    {
        List<List<GameObject>> matrix = controller.getMap().getMatrix();
        int indexi, indexj;
        for (int i = 1; i < matrix.Count; i++)
        {
            indexi = Mathf.RoundToInt(pos.x - i * dir.y);
            indexj = Mathf.RoundToInt(pos.y + i * dir.x);
            if (matrix[indexi][indexj] &&
                matrix[indexi][indexj].GetComponent<GenericProp>().getWalkable())
            {
                matrix[indexi][indexj].GetComponent<GenericProp>().setLethal(true);
                bullets.Add(new Bullet(bullet, transform.rotation, indexi, indexj, width));
            }
            else break;
        }
    }
    private void clearBullets()
    {
        if (bullets.Count != 0)
        {
            foreach (Bullet b in bullets)
            {
                b.destroy(controller);
            }
            bullets.Clear();
        }
    }

    public void setDir(Vector2 dir_) { dir = dir_; }

    public void setTurn(int turn_){ turn = turn_; }
}

public class Bullet
{
    private GameObject bullet;
    private int indexi, indexj;

    public Bullet(GameObject bullet_, Quaternion rot_, int indexi_, int indexj_, float width_)
    {
        bullet = GameObject.Instantiate(bullet_, new Vector3(width_ * indexi_, 2, width_ * indexj_), rot_);
        indexi = indexi_;
        indexj = indexj_;
    }
    public void destroy(Controller controller)
    {
        GameObject.Destroy(bullet);
        List<List<GameObject>> matrix = controller.getMap().getMatrix();
        matrix[indexi][indexj].GetComponent<GenericProp>().setLethal(false);
    }
}
