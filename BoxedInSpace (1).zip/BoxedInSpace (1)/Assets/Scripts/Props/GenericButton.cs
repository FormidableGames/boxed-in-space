﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GenericButton : GenericProp
{
    protected bool activated;

    override protected void Start()
    {
        base.Start();
        setHeight(1);
        walkable = true;
    }

    public abstract void press();
}
