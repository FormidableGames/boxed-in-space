﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GenericProp : MonoBehaviour
{

    protected Vector2 pos;
    protected bool lethal, walkable;
    protected Controller controller;
    protected float width, height;

    protected virtual void Start()
    {
        walkable = true;
        width = 1.6f;
        height = 1.6f;
        transform.position = new Vector3(pos.x * width, 0, pos.y * width);
    }
	
	public virtual void informProp()
	{
		
	}
	
	void OnDrawGizmos()
    {
		
		if(lethal)
		{
			Gizmos.color = Color.yellow;
			Gizmos.DrawWireSphere(transform.position, 1.0f);
		}
		
    }

    public Vector2 getPos() { return pos; }
    public bool getLethal() { return lethal; }
    public bool getWalkable() { return walkable; }

    public void setPos(Vector2 pos_) { pos = pos_; }
    public void setLethal(bool lethal_) { lethal = lethal_; }
    public void setWalkable(bool walkable_) { walkable = walkable_; }
    public void setController(Controller controller_) { controller = controller_; }
    public void setHeight(int h){ transform.position = new Vector3(transform.position.x, h*height, transform.position.z); }

}
