﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : GenericProp
{
    override protected void Start()
    {
        base.Start();
        setHeight(1);
        walkable = false;
    }
}
