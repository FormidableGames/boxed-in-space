﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bridge : ElectricProp
{
    override protected void Start()
    {
        base.Start();
        walkable = false;
    }

    override public void setOn(bool activated_) {
        base.setOn(activated_); 
		Debug.Log("ALGUIEN NECESITA UN PUENTE??");
        gameObject.SetActive(activated_);
        walkable = activated_;
    }
}
