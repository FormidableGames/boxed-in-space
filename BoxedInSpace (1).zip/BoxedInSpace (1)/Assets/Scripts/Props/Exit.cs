﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exit : GenericProp
{
    override protected void Start()
    {
        base.Start();
        walkable = false;
    }

    public void open()
    {
        gameObject.SetActive(false);
        walkable = true;
    }
}
