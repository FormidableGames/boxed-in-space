﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ice : GenericProp
{
	private bool active;
	
    override protected void Start()
    {
        base.Start();
        walkable = true;
    }
    
    public void freeze()
    {
        foreach (Transform child in transform)
        {
            if (child.gameObject.name == "Freeze") child.gameObject.SetActive(true);
            else if (child.gameObject.name == "Unfreeze") child.gameObject.SetActive(false);
        }
		active = true;
    }
    public void unfreeze()
    {
        foreach (Transform child in transform)
        {
            if(child.gameObject.name == "Freeze") child.gameObject.SetActive(false);
            else if (child.gameObject.name == "Unfreeze") child.gameObject.SetActive(true);
        }
		active = false;
    }
	
	public bool getActive(){return active;}
}
