﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyButton : GenericButton
{
    override public void press()
    {
        List<GameObject> props = controller.getMap().getPropsOfType<Exit>();
        foreach (GameObject p in props)
        {
            p.GetComponent<Exit>().open();
        }
    }
}
