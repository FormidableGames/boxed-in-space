﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : GenericProp
{
    public List<GameObject> objects;
	
	private GameObject obj;
	
	override protected void Start()
    {
        base.Start();
        walkable = true;
    }
	
	public void createObj(int type)
	{
		obj = GameObject.Instantiate(objects[type]);
		GenericObject genObj = obj.GetComponent<GenericObject>();
		genObj.setController(controller);
		genObj.setPos(pos);
		genObj.setTileParent(this);
	}
	
	override public void informProp()
	{
		base.informProp();
		if(obj!=null) {
			//Debug.Log("YOURE TAKING MA OBJET");
		}
	}
	
	public GameObject getGenericObject() { if(obj!=null)return obj; else return null;}
	
}
