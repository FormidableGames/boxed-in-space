﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserButton : GenericButton
{
    override public void press()
    {
        List<GameObject> props = controller.getMap().getPropsOfType<Laser>();
        foreach (GameObject p in props)
        {
            p.GetComponent<Laser>().rotate();
        }
    }
}
