﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectricProp : GenericProp
{
    private bool activated;

    override protected void Start()
    {
        base.Start();
        activated = false;
    }

    public virtual void setOn(bool activated_)
    {
        activated = activated_;
    }
}
