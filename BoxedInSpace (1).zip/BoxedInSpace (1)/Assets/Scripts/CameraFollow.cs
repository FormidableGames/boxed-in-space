﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
	Transform target;
	//[SerializeField]
	[SerializeField]Vector3 distance = new Vector3(0f, 15f, -10f);
	[SerializeField]Vector3 look = new Vector3(-.50f, 10f, -5f);
	float smoothTime = .4f;
	Vector3 velocity = Vector3.zero;
	
	
	/*
    void LateUpdate()
    {
        /*Vector3 targetPos = target.position+distance;
		Vector2 currPos = Vector3.SmoothDamp(transform.position, targetPos, ref velocity, smoothTime);
		transform.position = currPos;
		
		Transform t = transform;
		t.position = target.position+look;
		transform.LookAt(t);
		
    }*/
	
	
	void Start()
	{
		transform.rotation = Quaternion.Euler(new Vector3(45,0,0));
	}
	
	 void LateUpdate()
    {
        Vector3 targetPos = target.position+distance;
		Quaternion targetRot = Quaternion.Euler(new Vector3(45,0,0));
		
		Vector3 currPos = Vector3.SmoothDamp(transform.position, targetPos, ref velocity, smoothTime);
		Quaternion currRot = Quaternion.Slerp(transform.rotation, targetRot, smoothTime);
		
		transform.position = currPos;
		transform.rotation = currRot;
		
		//transform.LookAt(target);
		
    }
	
	
	public void setTarget(Transform target_){target = target_;}
}
