﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    public GameObject player;
	public GameObject[] easyProps;
    public GameObject[] mediumProps;
    public GameObject[] hardProps;

    private int round;
    private Map map;
	private List<float> timeBetweenTurns = new List<float>{0f, 0f, 0f, 0f, 0.25f};
	private float timer;
	private bool counting;
	private GameObject cam;
	
	private enum ControllerStates
	{
		PLAYER_MOV, ENEMIES_MOV, PLAYER_USE, ENEMIES_USE, LASER_MOV
	}
	
	private ControllerStates state;

    void Start()
    {
		MapController mapController = new MapController(this, player, easyProps, mediumProps, hardProps);
        map = mapController.create(0);
		
		cam = GameObject.FindWithTag("MainCamera");
		cam.GetComponent<CameraFollow>().setTarget(map.getPlayerInScene().transform);
		cam.GetComponent<CameraNav>().setTarget(map.getPlayerInScene().transform);
		cam.GetComponent<CameraNav>().enabled = false;
		
		state = ControllerStates.PLAYER_MOV;
		timer = timeBetweenTurns[0];
		counting = false;
		round = 1;
		FSM();
    }
	
	void Update()
	{
		if(counting)
		{
			timer-=Time.deltaTime;
			
			if(timer<=0.01f)
			{
				counting = false;
				startTurn();
			}				
		}
		/*
		if(Input.GetMouseButtonDown(0))
		{
			cam.GetComponent<CameraFollow>().enabled = !cam.GetComponent<CameraFollow>().enabled;
			cam.GetComponent<CameraNav>().enabled = !cam.GetComponent<CameraNav>().enabled;
		}*/
		/*
		if(Input.GetMouseButtonUp(0))
		{
			cam.GetComponent<CameraFollow>().enabled = !cam.GetComponent<CameraFollow>().enabled;
			cam.GetComponent<CameraNav>().enabled = !cam.GetComponent<CameraNav>().enabled;
		}*/
		/*
		if (Input.GetKeyDown("p"))
        {
            cam.GetComponent<CameraFollow>().enabled = !cam.GetComponent<CameraFollow>().enabled;
			cam.GetComponent<CameraNav>().enabled = !cam.GetComponent<CameraNav>().enabled;
        }*/
		
		//if(Input.touchCount > 0) Debug.Log("tachi");
	}
	
	
	// Cuando cada parte termina su jugada, se llama a este método 
	// para pasar el turno al siguiente
	public void finishedTurn()
	{
		//counting = true;
		startTurn();
	}
	
	private void startTurn()
	{
		if(state == ControllerStates.LASER_MOV)
		{
			round++; Debug.Log("roundo: "+round);
		}
		
		switch(state)
		{
			case ControllerStates.PLAYER_MOV:
			state = ControllerStates.ENEMIES_MOV;
			break;
			case ControllerStates.ENEMIES_MOV:
			state = ControllerStates.PLAYER_USE;
			break;
			case ControllerStates.PLAYER_USE:
			state = ControllerStates.ENEMIES_USE;
			break;
			case ControllerStates.ENEMIES_USE:
			state = ControllerStates.LASER_MOV;
			break;
			case ControllerStates.LASER_MOV:
			state = ControllerStates.PLAYER_MOV;
			break;
			default:
			break;
		}
		
		FSM();
	}
	
	// Se determina lo que se debe hacer según el estado
	private void FSM()
	{
		timer = timeBetweenTurns[(int)state];
		
		
		switch(state)
		{
				// Mueve el jugador
			case ControllerStates.PLAYER_MOV:
				map.getPlayerInScene().enableInput();
				break;
				// Mueven los enemigos
			case ControllerStates.ENEMIES_MOV:
				if(map.getEnemiesInScene().Count>0) map.getEnemyController().startEnemiesMovement();
				else finishedTurn();
				break;
				// El jugador utiliza su objeto
			case ControllerStates.PLAYER_USE:
				timer = 0f;
				if(map.getPlayerInScene().useObject()) timer = timeBetweenTurns[(int)state];
				break;
				// Los enemigos buscan al jugador
			case ControllerStates.ENEMIES_USE:
				
				// Set all tiles to false
				map.setAllToNonLethal();
		
				if(map.getEnemiesInScene().Count>0) map.getEnemyController().startEnemiesHunt();
				else finishedTurn();
				break;
			case ControllerStates.LASER_MOV:
			
				// Cambio láseres
				List<GameObject> lasers = map.getPropsOfType<Laser>();
				foreach(GameObject l in lasers){
					l.GetComponent<Laser>().broadcast();
				}
				
				// Comprobación de muertes
				map.getEnemyController().checkForDeaths();
				if(map.getTileInfo(map.getPlayerInScene().getPos(), Vector2.zero).GetComponent<GenericProp>().getLethal())
				{
					killPlayer("El láser se ha encendido y estabas a su alcance");
				}
				//else
				finishedTurn();
				break;
			default:
			break;
		}
		
		
	}
	
	// Se llama a este método cuando el jugador deba morir
	public void killPlayer(string reason)
	{
		Debug.Log(Random.Range(100, 999)+"YOU DIEEEEEEEEEEEEEEEEEEED because "+reason);
		reStart();
	}
	
	private void reStart()
	{
	}
	
    public Map getMap() { return map; }
	
	
}
