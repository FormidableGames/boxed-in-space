﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private int health;
    private Vector2 pos;
    private Controller controller;
	
	private bool inputEnabled;
	private bool movementGoingOn;
	
	private float speed;
	private Vector3 direction;
	private float epsilon; //minima distancia entre la posición final y la actual para finalizar el movimiento
	
	private float startTime;
	private float journeyLength;
	private Vector3 startPosition, targetPosition;
	private Quaternion startRotation, targetRotation;
	
	// Caras del cubo: 0-arriba, 1-delante, 2-abajo, 3-detras, 4-izq, 5-dcha
	private List<Face> faces;
	private List<string> facesNames;
	
	public List<GameObject> slots;

	public class Face{
		public GameObject slot;
		public GameObject item;
		public Face(GameObject slot_){slot = slot_; item=null;}
		public string print(){ if(item!=null) return item.GetComponent<GenericObject>().print(); else return "vacío";}
	}
	
    void Start()
    {
		float s = controller.getMap().getTileSize();
		transform.position = new Vector3(pos.x * s, s, pos.y * s);
		
		speed = 10f;
		epsilon = 0.0005f;
		journeyLength = s;
		inputEnabled = true;
		movementGoingOn = false;
		
		facesNames = new List<string>{"arriba", "delante", "abajo", "detras", "izq", "dcha"};
		faces = new List<Face>();
		for(int i=0; i<slots.Count; i++){ faces.Add(new Face(slots[i]));}
		
    }

    void Update()
    {
		if (inputEnabled) 
		{
			handleInput();
		}

		if(movementGoingOn)
		{
			movePlayer();		
		}
		
		if (Input.GetKeyDown("space"))
        {
            printFaces("");
        }
		
    }

	public void handleInput()
	{
		if (Input.GetKey (KeyCode.A)) {
			startPlayerMovement('A', Vector3.left, new Vector3(0, 0, 90));
		}
		else if (Input.GetKey (KeyCode.D)) {
			startPlayerMovement('D', Vector3.right, new Vector3(0, 0, -90));
		}
		else if(Input.GetKey (KeyCode.W)) {
			startPlayerMovement('W', Vector3.forward, new Vector3(90, 0, 0)); 
		}
		else if (Input.GetKey (KeyCode.S)) {
			startPlayerMovement('S', Vector3.back, new Vector3(-90, 0, 0)); 
		}
	}
	
	public void startPlayerMovement(char key, Vector3 dir, Vector3 angle)
	{
		direction = dir;
		
		// Recolocar el cubo para evitar la acumulación de error
		Vector3 roundedRotation = new Vector3(Mathf.Round(transform.eulerAngles.x), Mathf.Round(transform.eulerAngles.y), Mathf.Round(transform.eulerAngles.z));
		transform.rotation = Quaternion.Euler(roundedRotation);
		
		// Comprobar el tipo de la casilla a la que se avanza
		GenericProp prop = controller.getMap().getTileInfo(pos, new Vector2(dir.x, dir.z)).GetComponent<GenericProp>();
		if(prop!= null && prop.getWalkable())
		{
			// Change faces
			changeFaces(key);
			
			// Take objects from tiles and inform the tile under it
			takeObject(prop);
			prop.informProp();
		
			// Actual player movement
			pos = new Vector2(pos.x+dir.x, pos.y+dir.z);
		
			inputEnabled = false;
					
			startTime = Time.time;
			
			startPosition = transform.position;
			targetPosition = transform.position + dir * journeyLength;
			
			startRotation = transform.rotation;
			targetRotation = transform.rotation * Quaternion.Euler(Quaternion.Inverse(startRotation) * angle);
			movementGoingOn = true;
			
		}
		
	}
	
	private void changeFaces(char key)
	{
		List<Face> facesAux = new List<Face>(faces);
		
		switch(key){
			case 'A':
			faces[0] = facesAux[5]; faces[2] = facesAux[4]; faces[4] = facesAux[0]; faces[5] = facesAux[2]; 
			break;
			case 'D':
			faces[0] = facesAux[4]; faces[2] = facesAux[5]; faces[4] = facesAux[2]; faces[5] = facesAux[0];
			break;
			case 'W':
			faces[0] = facesAux[3]; faces[1] = facesAux[0]; faces[2] = facesAux[1]; faces[3] = facesAux[2];
			break;
			case 'S':
			faces[0] = facesAux[1]; faces[1] = facesAux[2]; faces[2] = facesAux[3]; faces[3] = facesAux[0];
			break;
			default:
			break;
		}
	}
	
	private void printFaces(string when)
	{
		string s = Random.Range(0,1000)+"  "+when;
		for(int i=0; i<faces.Count; i++)
		{
			s += facesNames[i]+": "+faces[i].print()+"  ";
		}
		Debug.Log(s);
	}
	
	private void takeObject(GenericProp prop)
	{
		if(faces[2].item == null && prop.GetComponent<Tile>()!=null && prop.GetComponent<Tile>().getGenericObject()!=null)
		{
			faces[2].item = prop.GetComponent<Tile>().getGenericObject();
			faces[2].item.GetComponent<Billboard>().enabled = false;
			faces[2].item.transform.parent = faces[2].slot.transform;
			faces[2].item.transform.localPosition = new Vector3(0, 0, 0);
			faces[2].item.transform.localRotation = Quaternion.Euler(new Vector3(faces[2].item.transform.localRotation.x, faces[2].item.transform.localRotation.y, faces[2].item.transform.localRotation.z));
        }
	}
	
	public bool useObject()
	{
		if(faces[0].item != null)
		{
			faces[0].item.GetComponent<GenericObject>().use(pos, new Vector2(direction.x, direction.z));
			Destroy(faces[0].item, .75f);
			return true;
		}else{
			// finish object usage turn
			controller.finishedTurn();
			return false;
		}
		
	}
	
	
	private void movePlayer()
	{
		// Distance moved = time * speed.
		float distCovered = (Time.time - startTime) * speed;
		
        // Fraction of journey completed = current distance divided by total distance.
        float fracJourney = distCovered / journeyLength;

        // Set our position and rotation as a fraction of the distance between the markers.
        transform.position = Vector3.Lerp(startPosition, targetPosition, fracJourney);
		transform.rotation = Quaternion.Slerp (startRotation, targetRotation, fracJourney);
			
		// End movement.
		float sqrdistance = (transform.position - targetPosition).sqrMagnitude;
		if(sqrdistance < epsilon)
		{
			transform.position = targetPosition;
			transform.rotation = targetRotation;
			
			movementGoingOn = false;
			
			if(controller.getMap().getTileInfo(pos, Vector2.zero).GetComponent<GenericProp>().getLethal())
			{
				controller.killPlayer("has caido en la ruta del láser");
			}
			//else?
			checkForIce();
			
			checkForButton();
			
		}
	}
	
	private void checkForIce()
	{
		GenericProp prop0 = controller.getMap().getTileInfo(pos, Vector2.zero).GetComponent<GenericProp>();
		GenericProp prop1 = controller.getMap().getTileInfo(pos, new Vector2(direction.x, direction.z)).GetComponent<GenericProp>();
		
		if(prop0!=null || prop1!=null)
		{
			bool ice0 = prop0.GetComponent<Ice>() != null && prop0.GetComponent<Ice>().getActive();
			bool ice1 = prop1.GetComponent<Ice>() != null && prop1.GetComponent<Ice>().getActive();
			
			if((ice0 || (ice0 && ice1))   &&   (prop1.getWalkable())){
				startIceMovement();
			} else{controller.finishedTurn();}
		}
		else {
			controller.finishedTurn();
		}
	}
	
	private void startIceMovement()
	{
		pos = new Vector2(pos.x+direction.x, pos.y+direction.z);
	
		startTime = Time.time;
		
		startPosition = transform.position;
		targetPosition = transform.position + direction * journeyLength;
		
		startRotation = transform.rotation;
		targetRotation = transform.rotation;
		
		movementGoingOn = true;
	}
	
	private void checkForButton()
	{
		GenericProp prop = controller.getMap().getTileInfo(pos, Vector2.zero).GetComponent<GenericProp>();
		if(prop!=null && prop.GetComponent<GenericButton>()!=null)
		{
			prop.GetComponent<GenericButton>().press();
		}
	}
	
	

	/////////////////////
	// GETTERS & SETTERS
	
    public int getHealth() { return health; }
    public Vector2 getPos() { return pos; }

    public void setHealth(int health_) { health = health_; }
    public void setPos(Vector2 pos_) { pos = pos_; }
    public void setController(Controller controller_) { controller = controller_;}
	public void enableInput(){ inputEnabled = true;}
}
