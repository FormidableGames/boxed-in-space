﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConfetiBomb : GenericObject
{
	override protected void Start()
	{
		// Variables del padre
        base.Start(); 
		
		objName = "Bomba confeti";
    }
	
	override public void use(Vector2 pos_, Vector2 dir)
	{
		GameObject prop;
		Vector2 dirAux;

        GetComponentInChildren<ParticleSystem>().Play();

        int[] dirs = {-1, 1,  0, 1,  1, 1,
					  -1, 0,         1, 0,
					  -1,-1,  0,-1,  1,-1};
					  
		for(int i=0; i<dirs.Length; i=i+2)
		{
			dirAux = new Vector2(dirs[i], dirs[i+1]);
			
			// Check for prop
			prop = controller.getMap().getTileInfo(pos_, dirAux);
			if(prop != null && prop.GetComponent<GenericProp>()!=null) 
			{
				prop.GetComponent<GenericProp>().setLethal(true);
				effectTransform.Add(prop.transform);
				if(prop.GetComponent<CrackedWall>()!=null) prop.GetComponent<CrackedWall>().destroy();
			}
			
		}
		
		draw = true;
		
		// Check for enemy
		controller.getMap().getEnemyController().checkForDeaths();
		controller.finishedTurn();
    }
}
