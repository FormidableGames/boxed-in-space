﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GenericObject : MonoBehaviour
{
	protected Vector2 pos;
    protected Controller controller;
	protected Tile tileParent;
	protected string objName = "OBJETO";
	//private Color color = Color.cyan;
	
	protected bool draw = false;
	protected List<Transform> effectTransform = new List<Transform>();
	
    protected virtual void Start()
    {
		float s = controller.getMap().getTileSize();
		transform.position = new Vector3(pos.x * s, s, pos.y * s);
		//GetComponent<SpriteRenderer>().color = color;
    }

    void Update()
    {
        
    }
	
	void OnDrawGizmos()
    {
		
		if(draw)
		{
			Gizmos.color = Color.red;
			foreach(Transform t in effectTransform) Gizmos.DrawWireSphere(t.position, 2.0f);
		}
    }

    public abstract void use(Vector2 pos_, Vector2 dir);
	
	public string print(){ return objName;}
	
	
	/////////////////////
	// GETTERS & SETTERS
	
	public Vector2 getPos() { return pos; }

    public void setPos(Vector2 pos_) { pos = pos_; }
    public void setController(Controller controller_) { controller = controller_;}
	public void setName(string name_){objName = name_;}
	public void setTileParent(Tile parent_){ tileParent = parent_;}
}
