﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Autodest : GenericObject
{
    override protected void Start()
	{
        base.Start(); 
		objName = "Autodestructor";
    }

	override public void use(Vector2 pos_, Vector2 dir)
	{
		controller.killPlayer("emm... has utilizado el autodestructor, inútil.");
    }
}