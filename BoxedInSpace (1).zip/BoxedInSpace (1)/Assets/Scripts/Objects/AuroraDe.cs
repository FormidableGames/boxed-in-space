﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AuroraDe : GenericObject
{
	
    override protected void Start()
	{
        base.Start(); 
		objName = "Des. aurora";
    }

	override public void use(Vector2 pos_, Vector2 dir)
	{
		GameObject prop;
		Vector2 dirAux;

        ParticleSystem[] part = GetComponentsInChildren<ParticleSystem>();
        foreach (ParticleSystem p in part)
            p.Play();

        int[] dirs = {        		0, 2, 
								    0, 1,
				     -2, 0, -1, 0,         1, 0, 2, 0,
								    0,-1,
								    0,-2
					  };
		
		for(int i=0; i<dirs.Length; i=i+2)
        {
            dirAux = new Vector2(dirs[i], dirs[i+1]);
			prop = controller.getMap().getTileInfo(pos_, dirAux);
			if(prop != null && prop.GetComponent<GenericProp>()!=null) 
			{
				prop.GetComponent<GenericProp>().setLethal(true);
				effectTransform.Add(prop.transform);
				if(prop.GetComponent<Ice>()!=null) prop.GetComponent<Ice>().unfreeze();
			}
		}
		
		draw = true;
		
		// Check for enemy deaths
		controller.getMap().getEnemyController().checkForDeaths();
		controller.finishedTurn();
		
    }
}
