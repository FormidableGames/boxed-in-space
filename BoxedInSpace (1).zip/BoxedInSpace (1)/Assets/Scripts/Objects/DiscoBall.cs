﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiscoBall : GenericObject
{
    override protected void Start()
	{
        base.Start(); 
		objName = "Bola de luces";
    }

	// 3 casillas en la dirección de movimiento
	override public void use(Vector2 pos_, Vector2 dir)
	{
		Vector2 dirAux = dir;
		GameObject prop;

        ParticleSystem part = GetComponentInChildren<ParticleSystem>();
        part.transform.eulerAngles = new Vector3(0, 90 + Mathf.Max(0, dir.y) * 180 + dir.x * 90, 0);
        ParticleSystem.ShapeModule sh = part.shape;
        Debug.Log(dir);
        sh.position = new Vector3(3 - 6*Mathf.Pow(dir.x, 2), 0, 0);
        part.Play();

        for (int i=0; i<3; i++)
		{
			prop = controller.getMap().getTileInfo(pos_, dirAux);
			if(prop != null && prop.GetComponent<GenericProp>()!=null) 
			{
				prop.GetComponent<GenericProp>().setLethal(true);
				effectTransform.Add(prop.transform);
				if(prop.GetComponent<Battery>()!=null) prop.GetComponent<Battery>().activate();
			}
			dirAux+=dir;
		}
		
		draw = true;
		
		// Check for enemy deaths
		controller.getMap().getEnemyController().checkForDeaths();
		controller.finishedTurn();
    }
}
