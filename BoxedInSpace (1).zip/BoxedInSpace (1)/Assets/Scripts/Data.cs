﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Data 
{
    public static int difficulty = 0, roomsNumber, healthNumber;
}
