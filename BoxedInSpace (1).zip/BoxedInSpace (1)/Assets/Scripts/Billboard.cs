﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Billboard : MonoBehaviour
{
    private GameObject cam;
    private Vector3 distance;
    void Start()
    {
        cam = GameObject.FindWithTag("MainCamera");
    }
    
    void Update()
    {
        distance = (transform.position - cam.transform.position).normalized;
        transform.forward = new Vector3(distance.x, transform.forward.y, distance.z);
    }
}
