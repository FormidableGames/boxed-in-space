﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LinearEnemy : GenericEnemy
{
	
	public enum LinearEnemyMovements{ VERTICAL,	HORIZONTAL}
	
	private Vector2 dirGLOB, dirLOC;
	private List<Vector2> globalHorDirs, globalVerDirs;
	private List<List<Vector2>> globalDirsList;
	
	private LinearEnemyMovements globalMovement, localMovement;
	private List<Vector2> globalDirs, localDirs;
	
	
    override protected void Start()
    {
		base.Start();
		
		globalVerDirs = new List<Vector2>{Vector2.up, Vector2.down};
		globalHorDirs = new List<Vector2>{Vector2.left, Vector2.right};
		globalDirsList = new List<List<Vector2>>{globalVerDirs, globalHorDirs};
		
		globalDirs = globalDirsList[(int)globalMovement];
		localDirs = globalDirsList[(int)localMovement];
		dirGLOB = globalDirs[0]; 
		dirLOC = localDirs[0];
		
    }

	override public void startMovement()
	{
		//Start player movement
		walk();
	}
	
	// PROPIOS
	
	public void setGlobalMovement(LinearEnemyMovements globalMovement_)
	{
		globalMovement = globalMovement_; 
		
		if(globalMovement == LinearEnemyMovements.VERTICAL)localMovement = LinearEnemyMovements.HORIZONTAL;
		else localMovement = LinearEnemyMovements.VERTICAL;
		
	}
	
	private bool tryStartMovement()
	{
		GenericProp prop = controller.getMap().getTileInfo(pos, dir).GetComponent<GenericProp>();
		if(prop!= null && prop.getWalkable() && prop.GetComponent<Bridge>() == null)
		{
			Vector3 direction = new Vector3(dir.x, 0, dir.y);
			pos = new Vector2(pos.x+direction.x, pos.y+direction.z);
		
			startTime = Time.time;
			
			startPosition = transform.position;
			targetPosition = transform.position + direction * journeyLength;
			
			movementGoingOn = true;
			
		}
		return movementGoingOn;
		
	}
	
	private void walk()
	{
		dir = dirLOC;
		if(!tryStartMovement())
		{
			if(dirLOC == localDirs[0]) dirLOC = localDirs[1];
			else dirLOC = localDirs[0];
			numTriesToMove++;
			if(numTriesToMove<3)
				turn();
		}
	}
	
	private void turn()
	{
		dir = dirGLOB;
		if(!tryStartMovement())
		{
			if(dirGLOB == globalDirs[0]) dirGLOB = globalDirs[1];
			else dirGLOB = globalDirs[0];
			dir = dirGLOB;
			numTriesToMove++;
			if(numTriesToMove<3)
				turn();
		}
		
	}
	
}