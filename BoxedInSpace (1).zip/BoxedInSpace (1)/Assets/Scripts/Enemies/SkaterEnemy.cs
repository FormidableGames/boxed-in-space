﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkaterEnemy : GenericEnemy
{
	public enum SkaterEnemyDirections { NORTH_WEST, NORTH_EAST, SOUTH_EAST, SOUTH_WEST}
	private SkaterEnemyDirections pathDir;
	private List<Vector2> directions = new List<Vector2>{Vector2.up+Vector2.left, Vector2.up+Vector2.right, Vector2.down+Vector2.right, Vector2.down+Vector2.left};
	private int distance;
    override protected void Start()
    {
        base.Start();
		dir = directions[(int)pathDir];
    }

	
	override public void startMovement()
	{
		distance = 0;
		numTriesToMove = 0;
		
		tryStart(pos);
		
	}
	
	override protected void checkPlayerInRoute()
	{
		
	}
	
	// PROPIOS
	private void tryStart(Vector2 pos_)
	{
		
		GenericProp prop = controller.getMap().getTileInfo(pos_, dir).GetComponent<GenericProp>();
		bool playerInDestination = controller.getMap().isPlayerInPosition(pos_+dir);
		if(prop!= null && prop.getWalkable() && !playerInDestination && prop.GetComponent<Bridge>() == null)
		{
			distance++;
			numTriesToMove++;
			if(numTriesToMove<1000) tryStart(pos_+dir);
		}
		else
		{
			Vector3 direction = new Vector3(dir.x, 0, dir.y);
			
			if(playerInDestination)
			{
				// Enemy detects player on its way
				distance++;
				pos = pos_+dir;
			}else pos = pos_;
		
			startTime = Time.time;
			
			float s = controller.getMap().getTileSize();
			journeyLength = Mathf.Sqrt(s*s*(distance * distance));
			
			startPosition = transform.position;
			targetPosition = transform.position + direction * journeyLength;
			
			movementGoingOn = true;
			
			//Cambiar dirección
			changeDir();
		}
	}
	
	private void changeDir()
	{
		Vector2 dirX = new Vector2(dir.x, 0);
		Vector2 dirY = new Vector2(0, dir.y);
		
		GenericProp propX = controller.getMap().getTileInfo(pos, dirX).GetComponent<GenericProp>();
		GenericProp propY = controller.getMap().getTileInfo(pos, dirY).GetComponent<GenericProp>();
		
		bool canWalkX = false;
		bool canWalkY = false;
		
		if(propX!=null && propX.getWalkable()) canWalkX = true;
		if(propY!=null && propY.getWalkable()) canWalkY = true;
		
		Vector2 blockedDir, transformedDir;
		
		if((canWalkX&&canWalkY)||(!canWalkX&&!canWalkY))
		{
			// Diagonal contraria
			dir = (-1)*dir;
			
		}else
		{
			if(canWalkX){
				blockedDir=dirY;
			} else {
				blockedDir=dirX;
			}
			Vector2 dirToTransform = new Vector2(Mathf.Abs(blockedDir.x), Mathf.Abs(blockedDir.y));
			transformedDir = Vector2.one - 2*dirToTransform;
			dir = dir * transformedDir;
		}
	}
	
	public void setPath(SkaterEnemyDirections direction_){ pathDir = direction_;}
	
	public void setPath(string direction_)
	{ 
		switch(direction_)
		{
			case "NW":
			pathDir = SkaterEnemyDirections.NORTH_WEST;
			break;
			case "NE":
			pathDir = SkaterEnemyDirections.NORTH_EAST;
			break;
			case "SE":
			pathDir = SkaterEnemyDirections.SOUTH_EAST;
			break;
			case "SW":
			pathDir = SkaterEnemyDirections.SOUTH_WEST;
			break;
			default: break;
		}
		
	}
	
}