﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController
{

	private Controller controller;
	private int numToCheck;
	private int num = 0;
	
	public EnemyController(Controller controller_){ controller = controller_;}
	
	// Comienza el movimiento de todos los enemigos y empieza a contar 
	// el último que termine de moverse dará la señal de aviso para pasar turno
	// (si no han pillado al jugador en su camino)
	public void startEnemiesMovement()
	{
		startChecking();
		foreach(GenericEnemy e in controller.getMap().getEnemiesInScene())
		{
			e.startMovement();
		}
	}
	private void startChecking(){ numToCheck = controller.getMap().getEnemiesInScene().Count;}
	private void reset(){ num = 0; numToCheck =0;}
	
	// Se llama a este método cuando el enemigo ha terminado de moverse (o ha muerto)
	// para pasar al turno de uso de objetos
	public void enemyFisnish()
	{
		num++;
		if(num>=numToCheck)
		{
			reset();
			controller.finishedTurn();
		}
	}
	
	// Todos los enemigos buscan al jugador en sus casillas próximas
	public bool startEnemiesHunt()
	{
		bool caught = false;
		foreach(GenericEnemy e in controller.getMap().getEnemiesInScene())
		{
			if(!caught) caught = e.seekPlayer();
		}
		if(caught)
		{
			controller.killPlayer("un enemigo se ha percatado de tu presencia");
		}
		//else
		//{
			controller.finishedTurn();
		//}
			
		return caught;
	}
	
	// Se llama a este método desde el uso de un objeto o laser.
	// Se comprueba si hay algún enemigo en alguna casilla marcada como letal
	// para terminar el turno de uso de objetos y laseres
	public void checkForDeaths()
	{
		List<GenericEnemy> enemiesToRemove = new List<GenericEnemy>();
		
		foreach(GenericEnemy e in controller.getMap().getEnemiesInScene())
		{
			GenericProp prop = controller.getMap().getTileInfo(e.getPos(), Vector2.zero).GetComponent<GenericProp>();
			if(prop!= null && prop.getLethal())
			{
				enemiesToRemove.Add(e);
			}
		}
		
		foreach(GenericEnemy r in enemiesToRemove)
		{
			controller.getMap().getEnemiesInScene().Remove(r);
			r.die();
		}
		
	}
	
}
