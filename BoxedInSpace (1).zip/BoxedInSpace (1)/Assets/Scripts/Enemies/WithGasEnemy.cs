﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WithGasEnemy : GenericEnemy
{
	private List<Vector2> clockwisePath = new List<Vector2> {Vector2.right, Vector2.right, Vector2.down, Vector2.down, Vector2.left, Vector2.left, Vector2.up, Vector2.up};
	private List<Vector2> counterclockwisePath = new List<Vector2> {Vector2.down, Vector2.down, Vector2.right, Vector2.right, Vector2.up, Vector2.up, Vector2.left, Vector2.left};
	private List<Vector2> path;
	private int start;
	
    override protected void Start()
    {
        base.Start();
		
    }
	
	override public void startMovement()
	{
		dir = path[start];
		start++;
		if(start>=path.Count) start=0;
		
		Vector3 direction = new Vector3(dir.x, 0, dir.y);
		pos = new Vector2(pos.x+direction.x, pos.y+direction.z);
	
		startTime = Time.time;
		
		startPosition = transform.position;
		targetPosition = transform.position + direction * journeyLength;
		
		movementGoingOn = true;
			
	}
	
	public void setPath(char p, int s)
	{
		if(p=='H')
		{
			path = clockwisePath; 
		}else
		{
			path=counterclockwisePath;
		}
		start = s;
	}
	
}
