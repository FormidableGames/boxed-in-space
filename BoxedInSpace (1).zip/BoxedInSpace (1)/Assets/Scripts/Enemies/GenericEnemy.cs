﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GenericEnemy : MonoBehaviour
{
	
    protected Vector2 pos;
	protected Vector2 dir;
    protected Controller controller;
	
	protected float speed;
	protected float epsilon;
	protected float startTime;
	protected float journeyLength;
	protected Vector3 startPosition, targetPosition;
	protected bool movementGoingOn;
	protected int numTriesToMove; // Por si acaso
	
    protected virtual void Start()
    {
		float s = controller.getMap().getTileSize();
		transform.position = new Vector3(pos.x * s, s, pos.y * s);
		
		speed = 10.0f;
		epsilon = 0.0005f;
		journeyLength = s;
		movementGoingOn = false;
		numTriesToMove = 0;
    }
	protected void Update()
	{
		if(movementGoingOn) moveEnemy();
	}
	
	public void die()
	{
		Destroy(gameObject);
	}
	
	// Busca al jugador en las cuatro direcciones
	public bool seekPlayer()
	{
		Vector2 dirAux;
		List<Vector2> dirs = new List<Vector2>{Vector2.up, Vector2.left, Vector2.right, Vector2.down};
					  
		foreach(Vector2 dir in dirs)
		{
			dirAux = pos+dir;
			if(controller.getMap().isPlayerInPosition(dirAux))
			{
				return true;
			}
		}
		return false;
	}

	public abstract void startMovement();
	protected virtual void checkPlayerInRoute()
	{
		
	}
	
	public virtual void moveEnemy()
	{
		// Distance moved = time * speed.
		float distCovered = (Time.time - startTime) * speed;
		
        // Fraction of journey completed = current distance divided by total distance.
        float fracJourney = distCovered / journeyLength;

        // Set our position as a fraction of the distance between the markers.
        transform.position = Vector3.Lerp(startPosition, targetPosition, fracJourney);
			
		// End movement.
		float sqrdistance = (transform.position - targetPosition).sqrMagnitude;
		if(sqrdistance < epsilon)
		{
			transform.position = targetPosition;
			
			movementGoingOn = false;
			numTriesToMove = 0;
			
			// Comprobar laser
			if(controller.getMap().getTileInfo(pos, Vector2.zero).GetComponent<GenericProp>().getLethal())
			{
				Debug.Log("ESTE ENEMIGO DEBERÍA MORIR"+ gameObject);
			}
			//else?
			
			// Si el enemigo se mueve y aterriza en la posición del jugador
			checkPlayerInPlace();
		}
	}
	
	public void checkPlayerInPlace()
	{
		if(controller.getMap().isPlayerInPosition(pos))
		{
			controller.killPlayer("estabas en el camino de un enemigo");
		}
		//else
		//{
			controller.getMap().getEnemyController().enemyFisnish();
		//}
	}
	
	
	/////////////////////
	// GETTERS & SETTERS
	
    public Vector2 getPos() { return pos; }
	
    public void setPos(Vector2 pos_) { pos = pos_; }
    public void setController(Controller controller_) { controller = controller_;}
}
